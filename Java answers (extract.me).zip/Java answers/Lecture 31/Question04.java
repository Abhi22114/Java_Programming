Write a class TestSubstring with a main method. The method receives one command line argument and print the output formed by the first three characters of the argument.

For example:
Cmd Args : Important
Imp


package q11194;


public class  TestSubstring{
	
	public static void main(String[] args) {
		
		System.out.println(args[0].substring(0,3));
		
		
		
		
		
		
		
		
	}
}