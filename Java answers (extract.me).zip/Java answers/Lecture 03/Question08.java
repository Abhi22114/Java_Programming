package q10804;
public class PrintHello {
	public static void main(String[] args) {
		System.out.println("Hello, I am learning Java!");
	}
}