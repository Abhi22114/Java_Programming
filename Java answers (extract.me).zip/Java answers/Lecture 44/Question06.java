Given
public class Main {
          public static void main(String args[]) {
              StringBuilder sb = new StringBuilder("Hi! Good Morning.");
              System.out.println(sb.length());
          }
}
Choose the correct output for the above program form the below options.

Answer

17