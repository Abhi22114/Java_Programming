Given
public class StringBuilderDemo {
	public static void main(String args[]) {
	StringBuilder sb = new StringBuilder("Hello ");
        sb.append("World");
        System.out.println(sb);
	}
}
What will be the output for the above program. Choose the correct option form the below.


Answer  

Hello World