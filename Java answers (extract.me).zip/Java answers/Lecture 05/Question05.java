Select all the correct answers
Answer 

In Binary System, decimal 3 is represented as 0b11