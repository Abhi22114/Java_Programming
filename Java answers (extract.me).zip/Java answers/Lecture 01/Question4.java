package q10734;
// A sample program
public class FirstJavaProgram {
	public static void main(String[] args) {
		System.out.println("India got its independence in 1947");
	}
}