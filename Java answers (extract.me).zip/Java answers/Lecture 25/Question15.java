The list of variables/references that are present in the method declaration are called parameters.

When the method is invoked the actual values passed are called arguments.

Select all the correct statements for the below code:
public int sum(int num1, int num2) { // statement 1
	return num1 + num2;
}

int total = sum(2, 3); // statement 2


Answers 
In statement 1, num1 and num2 are called parameters.
In statement 2, values 2 and 3 are called arguments.
