In every programming language there are certain keywords. Below are the keywords in Java:
abstract   continue   for          new         switch
assert     default    if           package     synchronized
boolean    do         goto         private     this
break      double     implements   protected   throw
byte       else       import       public      throws
case       enum       instanceof   return      transient
catch      extends    int          short       try
char       final      interface    static      void
class      finally    long         strictfp    volatile
const      float      native       super       while
These words have special meaning and usage. They cannot be used for naming variables, references or methods or classes.

null is not a keyword in Java.
if is a keyword