Understanding special characters 

Answer 

package q10812;
public class SpecialCharacters {
	public static void main(String[] args) {
		char aChar = 'A';
		char tabChar = '\t';
		char digitChar = '7';
		char newLineChar = '\n';
		char spaceChar = ' ';
		char hyphenChar = '-';
		char percentageChar = '%';
		System.out.print(aChar);
		System.out.print(tabChar);
		System.out.print(digitChar);
		System.out.print(newLineChar);
		System.out.print(spaceChar);
		System.out.print(hyphenChar);
		System.out.print(percentageChar);
	}
}