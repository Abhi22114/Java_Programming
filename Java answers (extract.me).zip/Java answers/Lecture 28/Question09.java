Write a class StringCompare witha a main method. The method receives one command line argument. Print true if the argument starts with the prefix pre, otherwise print false.

For Example:
Cmd Args : preparation
true


package q11167;




public class StringCompare {
	
	public static void main(String[] args) {
		
		String str1 = args[0];
		
		System.out.println(str1.startsWith("pre"));
		
	
		
		
		
		
	}
}

