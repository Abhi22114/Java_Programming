Create a class TestStringMethods with a main method. The method receives one command line argument. Convert the argument to uppercase and print the result.

For Example:
Cmd Args : India
INDIA

package q11163;
public class TestStringMethods {
	
	
	
	public static void main(String[] args) {
		
		
		
		String str = args[0];
		
		
		
		System.out.println(str.toUpperCase());
		
		
		
		
	}
}
