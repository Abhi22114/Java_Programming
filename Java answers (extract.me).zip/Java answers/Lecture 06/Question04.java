package q10770;
public class IntegerDemo {
	public static void main(String args[]) {
		int decimalOne = 1;
		System.out.println("decimalOne = " + decimalOne);
		int binaryThree = 0b11;
		System.out.println("binaryThree = " + binaryThree);
		int octalEight = 010;
		System.out.println("octalEight = " + octalEight);
		int hexTen = 0xA;
		System.out.println("hexTen = " + hexTen);
		int unicodeValueOfOne = '1';
		System.out.println("unicodeValueOfOne = " + unicodeValueOfOne);
		int unicodeValueOfA = 'A';
		System.out.println("unicodeValueOfA = " + unicodeValueOfA);
		int unicodeValueOfZ = 'Z';
		System.out.println("unicodeValueOfZ = " + unicodeValueOfZ);
	}
}