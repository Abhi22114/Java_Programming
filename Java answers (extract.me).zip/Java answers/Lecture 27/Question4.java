Fix the text in the main method using an escape character to produce the below output.

There is a single double-quote before "BLUE


package q11147;
public class EscapeSequence {
	public static void main(String[] args) {
		String text = "There is a single double-quote before \"BLUE";
		System.out.println(text);
	}
}