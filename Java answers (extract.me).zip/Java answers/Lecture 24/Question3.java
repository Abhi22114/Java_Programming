Identify the errors in the given code and correct them.


package q11159;
public class Student {
	private String id;
	private String name;
	private int age;
	private char gender;
}

