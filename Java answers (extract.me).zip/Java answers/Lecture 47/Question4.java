Click Submit to find out the problem.

The code should actually print the fourth element passed in the arguments to the main method.

[Hint: Click on the animating blue arrow in the exception stack trace to understand the error.]



package q11320;
public class ExceptionDemo4 {
	public static void main(String args[]) {
		System.out.println(args[3]);
	}
}