Select all the correct statements for the below code:
public class Demo {
	public static void main(String[] args) {
		System.out.print("Up ");
		System.out.print("up");
		System.out.print(" and away!");
	}
}



Answers

The output will be as given below:
Up up and away!