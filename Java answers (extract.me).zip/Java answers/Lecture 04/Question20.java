In Java, a String is enclosed in double quotes and not in single quotes. We will learn more about Strings in the ensuing sections. Identify the error and correct the code.

package q10766;
public class PrintHello {
	public static void main(String[] args) {
		System.out.println("Hello, I am learning Java!");
	}
}

