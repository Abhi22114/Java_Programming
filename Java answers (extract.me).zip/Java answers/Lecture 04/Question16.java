Identify the error in the below code and correct it.

Note: Please don't change the package name.

;

'

package q10762;
public class PrintHello {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}