package q10795;
public class CommandLineArgumentDemo {
	public static void main(String[] args) {
		//Write the code fragment in the below println(     ) method to print only the first argument
		System.out.println(  args[0]  );
	}
}