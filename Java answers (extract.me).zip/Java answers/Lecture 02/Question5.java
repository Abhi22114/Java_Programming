package q10754;
public class Student  {

}