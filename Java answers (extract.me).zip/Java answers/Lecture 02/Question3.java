package q10737;
public class Student {
	
}